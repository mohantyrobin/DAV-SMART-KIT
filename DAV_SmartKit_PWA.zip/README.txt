DAV SmartKit — free installable web app

CONTENTS
- index.html: your original student tools website, branded DAV SmartKit
- manifest.webmanifest: app name, icon and install settings
- sw.js: offline cache for the app shell
- icons/: app icons

PUBLISH FREE WITH GITHUB PAGES
1. Sign in to GitHub and create a new PUBLIC repository named dav-smartkit.
2. Upload all files and folders from this ZIP (upload the contents, not the ZIP itself).
3. In the repository open Settings > Pages. Under Build and deployment choose Deploy from a branch, select main and / (root), then Save.
4. Wait for GitHub Pages to publish. Open the HTTPS link on Android Chrome.
5. In Chrome menu choose Install app or Add to Home screen.

IMPORTANT
- Hosting and installation can be free. This is a PWA, not a Play Store listing or an APK.
- The website needs to be hosted over HTTPS for installation and offline support.
- Test the published site before sharing it.
